// cia rasom js koda
5 + 5;

// sukuriam kintamaji
// = priskiria desine puse kairiai
let vardas = 'James';

// sukuriu h1 el
const h1El = document.createElement('h1');
// pridedu jam tekstine reiksme
h1El.textContent = vardas;
// patalpinu i body taga
document.body.append(h1El);

// pakeisti dydi
h1El.style.fontSize = '5rem';

// vardas = 'Mike'
// vardas = 500
// vardas = true

console.log(5 + 5);
console.log(vardas);
