# uzd1 

1. susikurti kintamuosius vardas, salis, megstamiausiasSkaicius, megstamiausia savaites diena (skaiciais 1-7)

2. isvedam i konsole visus savo kintamiuosiu atskirai

3. atspausdinam konsoleje savo megstamiausio skaiciau ir dienos daugyba

4. atspausdinam konsoleje savo megstamiausio skaiciau is dienos sudeti

5. atspausdinam konsoleje naudodami kintamuosius "as esu John. noreciau keliausi i Jamaika. Mano megstamiausias skaicius yra 777"