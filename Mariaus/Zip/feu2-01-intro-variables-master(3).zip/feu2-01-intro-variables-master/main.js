'use strict';
console.log('main.js');

console.log(5 + 150);

let myName = 'Mike';

myName = 5;

myName = true;

console.log(typeof myName);

let myFavoriteColorInAutum = 'tomato';

// Pagrindiniai tipai
// string
let var1 = 'I am a string';
// Number
let var2 = 500;
// Boolean
let isUserLoggedIn = false;

// null ir undefined
let var3; // undefined
var3 = 45; // 45
// isvalyti reiksme
var3 = null;

// let do a sentence

let person = 'James';
let action = 'is living in London';
let time = 'in 2022';

let sentence = 'The ' + person + ' ' + action + ' ' + time + '.';
let sentenceBacktic = `The ${person} ${action} ${time}. Yeyy!`;

console.log(sentence);
console.log(sentenceBacktic);

// nusitaikyti i el su id 'result'
const resultEl = document.getElementById('result');
/// ikelti teksta
resultEl.textContent = sentenceBacktic;
