# uzd1 

1. susikurti kintamuosius vardas, salis, megstamiausiasSkaicius, megstamiausia savaites diena (skaiciais 1-7)

2. isvedam i konsole visus savo kintamiuosiu atskirai

3. atspausdinam konsoleje savo megstamiausio skaiciau ir dienos daugyba

4. atspausdinam konsoleje savo megstamiausio skaiciau is dienos sudeti

5. atspausdinam konsoleje naudodami kintamuosius "as esu John. noreciau keliausi i Jamaika. Mano megstamiausias skaicius yra 777"

6. sukurti 4 skaicius kintamuosius
   
7. apskaiciuoti ju vidurki ir priskirti kintamajam avg.

8. sukurti nauja faila room.js. Jame susikurti 3 kintamuosius kambario auksciui, plociui ir gyliui. panaudojant kintamuosius isvesti kambario turi, sienu plota, grindu plota, perimetra.
   1. atspausdinti konsoleje: jusu kambario plotas yra xxx kai ilgis: xx plotis: xx, aukstis:xx
   2. extra yra 2 langai 1.5 x 1.5 ir durys 0.8 x 2 reikia atimti ju plotus is bendro.
   
9. Sukurti informacijos apie save ar savo pazystama objekta. Itrauki informacijos savo nuoziura bent 7 "key: value" savybes. pvz, miestas, amzius, spalva, hobis ir pan.

10. Sukurti du skaitinius kintamuosius num11 ir num12 ir isbandyti palyginimo operatorius '>','<', '<=', '>=', '==='. pvz console.log('num11 < num12', num11 < num12) 